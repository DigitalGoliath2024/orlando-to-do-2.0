import { createClient } from '@supabase/supabase-js';

// Create a single supabase client for interacting with your database
const supabaseUrl = import.meta.env.PUBLIC_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Supabase credentials not found. Make sure your environment variables are set correctly.');
  console.log('Current environment:', {
    url: supabaseUrl ? 'Set' : 'Not set',
    key: supabaseAnonKey ? 'Set' : 'Not set'
  });
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder-url.supabase.co',
  supabaseAnonKey || 'placeholder-key'
);

// Add error handling wrapper
export const handleSupabaseError = (error: any) => {
  if (error) {
    console.error('Supabase error:', error);
    if (error.message?.includes('JWT')) {
      console.error('Authentication error - please check your Supabase configuration');
    } else if (error.message?.includes('connection')) {
      console.error('Connection error - please check your Supabase URL and API key');
    }
    throw new Error(error.message || 'An error occurred while connecting to the database');
  }
};

// Add a health check function
export const checkSupabaseConnection = async () => {
  try {
    const { data, error } = await supabase.from('events').select('count').limit(1);
    if (error) {
      throw error;
    }
    console.log('Supabase connection successful');
    return true;
  } catch (error) {
    console.error('Supabase connection failed:', error);
    return false;
  }
};

// Initialize connection check
checkSupabaseConnection().then(isConnected => {
  if (!isConnected) {
    console.error('Failed to connect to Supabase. Please check your configuration.');
  }
});